AppHotelPlus - Projeto exemplo .NET MAUI

Estrutura mínima criada automaticamente:

- Models/Hospede.cs
- ViewModels/HospedeViewModel.cs
- Views/MainPage.xaml
- Views/CadastroPage.xaml
- Views/ListaHospedesPage.xaml

Instruções:
1) Abra o Visual Studio (2022/2025) com workload .NET MAUI instalado.
2) Abra o arquivo AppHotelPlus.sln ou o AppHotelPlus.csproj.
3) Restaure pacotes (se solicitado) e execute o app em um emulador ou dispositivo.

Observação: plataformas específicas (Platforms/Android, iOS, Windows) serão geradas pelo Visual Studio quando você executar o projeto.
